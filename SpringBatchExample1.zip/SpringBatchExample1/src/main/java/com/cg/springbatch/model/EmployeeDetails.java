package com.cg.springbatch.model;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "EmployeeDetails")
public class EmployeeDetails {

	private int id;
	private String name;
	private long salary;
		
	@XmlElement(name = "id")
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
		@XmlElement(name = "name")
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@XmlElement(name = "salary")
	public long getSalary() {
		return salary;
	}
	public void setSalary(long salary) {
		this.salary = salary;
	}
		@Override
	public String toString() {
		return "EmployeeDetails[id=" + id + ", name=" + name + ", salary=" + salary + "]";
	}


}

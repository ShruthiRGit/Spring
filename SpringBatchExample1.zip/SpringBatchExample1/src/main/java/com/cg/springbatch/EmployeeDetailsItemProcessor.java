package com.cg.springbatch;

import org.springframework.batch.item.ItemProcessor;

import com.cg.springbatch.model.EmployeeDetails;

public class EmployeeDetailsItemProcessor implements ItemProcessor<EmployeeDetails, EmployeeDetails>{

	
	public EmployeeDetails process(EmployeeDetails emp) throws Exception {
		System.out.println("Employee Details :"+emp);
		
	/*	
		 * Only return results which are more than 60%
		 * 
		 */
		
		return emp;
	}

}
